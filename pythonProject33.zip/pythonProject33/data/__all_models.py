# файл, хранящий все модели

from . import users
from . import news
